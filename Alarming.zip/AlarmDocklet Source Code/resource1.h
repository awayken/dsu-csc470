//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Alarming.rc
//
#define IDD_CONFIG                      166
#define RADIO_ONCE                      1003
#define RADIO_DAILY                     1004
#define RADIO_WEEK                      1005
#define RADIO_WEEKEND                   1006
#define IDC_RECUR                       1007
#define TEXT_STANDARD                   1010
#define TEXT_TEST                       1010
#define RADIO_STANDARD                  1012
#define RADIO_QUICK                     1013
#define DROP_QUICK                      1017
#define DROP_NOTIFY                     1018
#define TEXT_PARAM                      1019
#define LABEL_ACTION                    1021
#define TEXT_NAME                       1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
